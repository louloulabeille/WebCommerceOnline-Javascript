﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnqueteAFPANA.BOL
{
  public class AppellationRome
    {
        public int CodeAppellationRome { get; set; }
        public string LibelleAppellationRome { get; set; }
        public string CodeRome { get; set; }
    }
}
