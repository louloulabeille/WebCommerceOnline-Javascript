﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnqueteAFPANA.BOL
{
   public class TitreCivilite
    {
        public int Code { get; set; }
        public string Abrege { get; set; }
        public string Complet { get; set; }
    }
}
