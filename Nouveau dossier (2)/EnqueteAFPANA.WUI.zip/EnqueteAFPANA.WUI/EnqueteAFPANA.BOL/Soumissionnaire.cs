﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnqueteAFPANA.BOL
{
    public class Soumissionnaire
    {
        public string IdentifiantMailing { get;  set; }
        public int IdQuestionnaire { get; set; }
        public string MatriculeBeneficiaire { get; set; }
        public bool? ReponseEmploi { get; set; }
        public DateTime? DateEnregistrementReponse { get; set; }

    }
}
