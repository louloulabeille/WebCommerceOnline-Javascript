﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EnqueteAFPANA.BOL;
using EnqueteAFPANA.DAC;

namespace EnqueteAFPANA.Tests
{
    class Program
    {
        static void Main(string[] args)
        {
            DBConnexion.DbConString = Properties.Settings.Default.EnqueteCS;
            Console.WriteLine("Element SoumissionaireMV ");
            SoumissionnaireMV soumisMV = SoumissionnaireMVDAC.Instance.GetSoumissionnaireMVById("BC51E8C2-0E82-41B5-87E5-134DDD9183EA");
            Console.WriteLine($"Id : {soumisMV.IdentifiantMailing}  {soumisMV.LibelleQuestionnaire} formation : {soumisMV.LibelleOffreFormation}");
            Console.WriteLine($"Matricule {soumisMV.MatriculeBeneficiaire} nom : {soumisMV.NomBeneficiaire}  {soumisMV.PrenomBeneficiaire} ");
            Console.WriteLine("Soumissionnaires n'ayant pas répondu");
            SoumissionnaireDAC.Instance.GetSoumissionnairesSansReponse()
                .ToList<Soumissionnaire>().ForEach(s => Console.WriteLine(
                  $"Matricule : {s.MatriculeBeneficiaire} id Mailing : {s.IdentifiantMailing} réponse emploi {(s.ReponseEmploi == null ? "sans" : "OK")} "));
            Console.WriteLine("Essai avec ID");
            Soumissionnaire s2 = SoumissionnaireDAC.Instance.GetSoumissionnaireById("BC51E8C2-0E82-41B5-87E5-134DDD9183EA");
                Console.WriteLine($"Matricule : {s2.MatriculeBeneficiaire} id Mailing : {s2.IdentifiantMailing} réponse emploi {(s2.ReponseEmploi == null ? "sans" : "OK")} ");
            Console.ReadLine();

        }
    }
}
