﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using EnqueteAFPANA.DAC;
using EnqueteAFPANA.BOL;

namespace EnqueteAFPANA.WUI
{
    public partial class Enquete_Partie1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            GetIntroduction(Request.QueryString["IdentifiantMailing"]);
        }
        private void GetIntroduction(string IdentifiantMailing)
        {

            StringBuilder sb = new StringBuilder();
            SoumissionnaireMV soumissionnaireMV = SoumissionnaireMVDAC.Instance.GetSoumissionnaireMVById(IdentifiantMailing);

            sb.Append($@"<span>Bonjour {soumissionnaireMV.TitreCiviliteComplet} {soumissionnaireMV.PrenomBeneficiaire} {soumissionnaireMV.NomBeneficiaire} </span><br/>");
            sb.Append(@"<span>Merci de consacrer quelques instants à la réponse à notre enquête.</span><br/>");
            sb.Append($@"<span>Avez-vous exercé un emploi depuis le {soumissionnaireMV.DateSortieBeneficiaire.Value.ToLongDateString()}</span><br/>");
            this.titreEnquete.InnerHtml = string.Format($@"<span>{soumissionnaireMV.LibelleQuestionnaire}</span><br/>");
            this.introduction.InnerHtml = sb.ToString();

        }
    }
}
