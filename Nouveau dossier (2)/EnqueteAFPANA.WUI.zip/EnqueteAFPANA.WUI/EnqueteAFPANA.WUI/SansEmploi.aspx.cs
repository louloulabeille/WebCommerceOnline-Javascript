﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EnqueteAFPANA.BOL;
using EnqueteAFPANA.DAC;

namespace EnqueteAFPANA.WUI
{
    public partial class SansEmploi : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            EnregistrerReponse(Request.QueryString["IdentifiantMailing"]);
            Response.Redirect("Remerciements.aspx");
        }
        private void EnregistrerReponse(string id)
        {
            Soumissionnaire soumissionnaire = SoumissionnaireDAC.Instance.GetSoumissionnaireById(id);
            soumissionnaire.DateEnregistrementReponse = DateTime.Now;
            soumissionnaire.ReponseEmploi = false;
            SoumissionnaireDAC.Instance.Update(soumissionnaire);
        }
    }
}