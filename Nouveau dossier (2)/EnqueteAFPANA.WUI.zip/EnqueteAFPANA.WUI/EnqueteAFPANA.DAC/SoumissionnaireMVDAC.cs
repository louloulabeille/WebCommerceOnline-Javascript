﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EnqueteAFPANA.BOL;

namespace EnqueteAFPANA.DAC
{
   public class SoumissionnaireMVDAC
    {
        private static SoumissionnaireMVDAC _instance = null;
        private static object _verrou = new object();
        /// <summary>
        /// Privatisation du constructeur
        /// </summary>
        private SoumissionnaireMVDAC() { }

        /// <summary>
        /// Méthode de création d'instance publique
        /// </summary>
        public static SoumissionnaireMVDAC Instance
        {
            get
            {
                lock (_verrou)
                {
                    if (_instance == null)
                    {
                        _instance = new SoumissionnaireMVDAC();
                    }
                }
                return _instance;
            }
        }

        public SoumissionnaireMV GetSoumissionnaireMVById(string id)
        {
            using (SqlConnection cnx = DBConnexion.CreateInstance.GetDBConnection())
            using (SqlCommand cmd = cnx.CreateCommand())
            {
                cmd.CommandType = CommandType.Text;

                cmd.CommandText = "SELECT [IdentifiantMailing], [MatriculeBeneficiaire] ," +
                                   "[TitreCiviliteComplet] ,[NomBeneficiaire],[PrenomBeneficiaire]" +
                                   ",[LibelleOffreFormation],[DateSortieBeneficiaire],[NomEtablissement]" +
                                   ",[LibelleQuestionnaire],[DateEntreeBeneficiaire] " +
                                   " FROM[Enquetes].[dbo].[Vue_Soumissionnaire] where IdentifiantMailing " +
                                   " = @IdentifiantMailing";
                cmd.Parameters.Add(new SqlParameter()
                {
                    Direction = ParameterDirection.Input,
                    ParameterName = "@IdentifiantMailing",
                    SqlDbType = System.Data.SqlDbType.UniqueIdentifier,
                    Size = 16,
                    Value = Guid.Parse(id)
                }) ;
               
                using (SqlDataReader rd = cmd.ExecuteReader())
                {
                    return rd.Read() ? ChargerDonnees(rd) : null;
                }
            }

        }

        private SoumissionnaireMV ChargerDonnees(SqlDataReader rd)
        {
            SoumissionnaireMV soumissionaireVM = new SoumissionnaireMV()
            {
                IdentifiantMailing = rd["IdentifiantMailing"].ToString(),
                MatriculeBeneficiaire = rd["MatriculeBeneficiaire"].ToString(),
                TitreCiviliteComplet = rd["TitreCiviliteComplet"].ToString(),
                NomBeneficiaire = rd["NomBeneficiaire"].ToString(),
                PrenomBeneficiaire = rd["PrenomBeneficiaire"].ToString(),
                DateEntreeBeneficiaire = (DateTime)rd["DateEntreeBeneficiaire"],
                DateSortieBeneficiaire = rd["DateSortieBeneficiaire"]!=null ? (DateTime?)rd["DateSortieBeneficiaire"] :null,
                LibelleOffreFormation = rd["LibelleOffreFormation"].ToString(),
                LibelleQuestionnaire = rd["LibelleQuestionnaire"].ToString(),
                NomEtablissement = rd["NomEtablissement"].ToString()
            };
            return soumissionaireVM;
        }

    }
}