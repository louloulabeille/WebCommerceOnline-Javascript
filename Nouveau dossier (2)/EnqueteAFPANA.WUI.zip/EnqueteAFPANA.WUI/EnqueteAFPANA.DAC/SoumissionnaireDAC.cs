﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using EnqueteAFPANA.BOL;

namespace EnqueteAFPANA.DAC
{
   public class SoumissionnaireDAC
    {
     
        private static SoumissionnaireDAC _instance = null;
        private static object _verrou = new object();
        /// <summary>
        /// Privatisation du constructeur
        /// </summary>
        private SoumissionnaireDAC() { }

        /// <summary>
        /// Méthode de création d'instance publique
        /// </summary>
        public static SoumissionnaireDAC Instance
        {
            get
            {
                lock (_verrou)
                {
                    if (_instance == null)
                    {
                        _instance = new SoumissionnaireDAC();
                    }
                }
                return _instance;
            }
        }

        public Soumissionnaire GetSoumissionnaireById(string id)
        {
            using (SqlConnection cnx = DBConnexion.CreateInstance.GetDBConnection())
            using (SqlCommand cmd = cnx.CreateCommand())
            {
                cmd.CommandType = CommandType.Text;

                cmd.CommandText = "SELECT [IdentifiantMailing], [MatriculeBeneficiaire] ," +
                                   "[IdQuestionnaire] ,[ReponseEmploi],[DateEnregistrementReponse]" +
                                   " FROM[Enquetes].[dbo].[Soumissionnaire] where IdentifiantMailing = @IdentifiantMailing";
                cmd.Parameters.Add(new SqlParameter()
                {
                    Direction = ParameterDirection.Input,
                    ParameterName = "@IdentifiantMailing",
                    SqlDbType = System.Data.SqlDbType.UniqueIdentifier,
                    Size = 16,
                    Value = Guid.Parse(id)
                });
                using (SqlDataReader rd = cmd.ExecuteReader())
                {
                    return rd.Read() ? ChargerDonnees(rd) : null;
                }
            }
        }
        public HashSet<Soumissionnaire> GetSoumissionnairesSansReponse()
        {
            using (SqlConnection cnx = DBConnexion.CreateInstance.GetDBConnection())
            using (SqlCommand cmd = cnx.CreateCommand())
            {
                cmd.CommandType = CommandType.Text;

                cmd.CommandText = "SELECT [IdentifiantMailing], [MatriculeBeneficiaire] ," +
                                   "[IdQuestionnaire] ,[ReponseEmploi],[DateEnregistrementReponse]" +
                                   " FROM[Enquetes].[dbo].[Soumissionnaire] where DateEnregistrementReponse is null";
                return AlimenterListe(cmd);
            }
        }
        private HashSet<Soumissionnaire> AlimenterListe(SqlCommand cmd)
        {
            HashSet<Soumissionnaire> soumissionnaires = new HashSet<Soumissionnaire>();
            using (SqlDataReader rd = cmd.ExecuteReader())
            {
                while (rd.Read())
                {
                    soumissionnaires.Add(ChargerDonnees(rd));
                }
            }
            return soumissionnaires;
        }

        private Soumissionnaire ChargerDonnees(SqlDataReader rd)
        {
            Soumissionnaire soumissionnaire = new Soumissionnaire
            {
                IdentifiantMailing = rd["IdentifiantMailing"].ToString(),
                IdQuestionnaire = (int)rd["IdQuestionnaire"],
                MatriculeBeneficiaire = rd["MatriculeBeneficiaire"].ToString(),
                ReponseEmploi = (rd["ReponseEmploi"] != DBNull.Value) ? (bool?)rd["ReponseEmploi"] : null,
                DateEnregistrementReponse = rd["DateEnregistrementReponse"] != DBNull.Value ? (DateTime?)rd["DateEnregistrementReponse"] : null
            };

            return soumissionnaire;
        }
        public void Update(Soumissionnaire soumissionnaire)
        {
            using (SqlConnection cnx = DBConnexion.CreateInstance.GetDBConnection())
            using (SqlCommand command = cnx.CreateCommand())
            {

                command.CommandText = "dbo.Soumissionnaire_Update";
                command.CommandType = CommandType.StoredProcedure;

               
                // Ajout des paramètres 
              
                command.Parameters.Add(new SqlParameter
                {
                    ParameterName = "@RETURN_VALUE",
                    SqlDbType = SqlDbType.Int,
                    Direction = ParameterDirection.ReturnValue
                });

                command.Parameters.Add(new SqlParameter
                {
                    ParameterName = "@IdentifiantMailing",
                    SqlDbType = SqlDbType.UniqueIdentifier,
                    Direction = ParameterDirection.Input
                });

                command.Parameters.Add(new SqlParameter
                {
                    ParameterName = "@IdQuestionnaire",
                    SqlDbType = SqlDbType.Int,
                    Direction = ParameterDirection.Input
                });

                command.Parameters.Add(new SqlParameter
                {
                    ParameterName = "@MatriculeBeneficiaire",
                    SqlDbType = SqlDbType.Char,
                    Direction = ParameterDirection.Input,
                    Size = 8
                });

                command.Parameters.Add(new SqlParameter
                {
                    ParameterName = "@ReponseEmploi",
                    SqlDbType = SqlDbType.Bit,
                    Direction = ParameterDirection.Input
                });

                command.Parameters.Add(new SqlParameter
                {
                    ParameterName = "@DateEnregistrementReponse",
                    SqlDbType = SqlDbType.Date,
                    Direction = ParameterDirection.Input
                });
               
                // Passage des valeurs
                command.Parameters["@IdentifiantMailing"].Value = Guid.Parse(soumissionnaire.IdentifiantMailing);
                command.Parameters["@IdQuestionnaire"].Value = soumissionnaire.IdQuestionnaire;
                command.Parameters["@MatriculeBeneficiaire"].Value = soumissionnaire.MatriculeBeneficiaire;
                command.Parameters["@ReponseEmploi"].Value = soumissionnaire.ReponseEmploi;
                command.Parameters["@DateEnregistrementReponse"].Value = soumissionnaire.DateEnregistrementReponse;
              
                if (command.ExecuteNonQuery() == 0)
                {
                    throw new Exception("L'enregistrement n'a pu être réalisé.");
                }
            }
        }

    }
}
