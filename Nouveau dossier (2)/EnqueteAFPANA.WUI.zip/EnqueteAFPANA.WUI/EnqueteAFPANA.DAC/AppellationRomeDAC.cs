﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using EnqueteAFPANA.BOL;

namespace EnqueteAFPANA.DAC
{
   public class AppellationRomeDAC
    {
     
        private static AppellationRomeDAC _instance = null;
        private static object _verrou = new object();
        /// <summary>
        /// Privatisation du constructeur
        /// </summary>
        private AppellationRomeDAC() { }

        /// <summary>
        /// Méthode de création d'instance publique
        /// </summary>
        public static AppellationRomeDAC Instance
        {
            get
            {
                lock (_verrou)
                {
                    if (_instance == null)
                    {
                        _instance = new AppellationRomeDAC();
                    }
                }
                return _instance;
            }
        }

       
        public HashSet<AppellationRome> GetAppellationsRomeContains(string contenu)
        {
            using (SqlConnection cnx = DBConnexion.CreateInstance.GetDBConnection())
            using (SqlCommand cmd = cnx.CreateCommand())
            {
                cmd.CommandType = CommandType.Text;

                cmd.CommandText = "SELECT [CodeAppellationRome],[LibelleAppellationRome],[CodeRome] "+
                " FROM[Enquetes].[dbo].[AppellationRome] Where LibelleAppellationRome Like @Contient";

                cmd.Parameters.Add(new SqlParameter()
                {
                    Direction = ParameterDirection.Input,
                    ParameterName = "@Contient",
                    SqlDbType = System.Data.SqlDbType.VarChar,
                    Value = $"%{contenu}%"
                }) ;
                return AlimenterListe(cmd);
            }
        }
        private HashSet<AppellationRome> AlimenterListe(SqlCommand cmd)
        {
            HashSet<AppellationRome> appellationsRome = new HashSet<AppellationRome>();
            using (SqlDataReader rd = cmd.ExecuteReader())
            {
                while (rd.Read())
                {
                    appellationsRome.Add(ChargerDonnees(rd));
                }
            }
            return appellationsRome;
        }

        private AppellationRome ChargerDonnees(SqlDataReader rd)
        {
            AppellationRome appellation = new AppellationRome
            {
                CodeAppellationRome = (int)rd["CodeAppellationRome"],
                CodeRome = rd["CodeRome"].ToString(),
                LibelleAppellationRome = rd["LibelleAppellationRome"].ToString()               
            };

            return appellation;
        }
   
    }
}
